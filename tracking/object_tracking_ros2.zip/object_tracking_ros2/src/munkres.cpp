#include "munkres.h"


template class Munkres<double>;
template class Munkres<float>;
template class Munkres<int>;