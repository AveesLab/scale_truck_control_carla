#include "matrix.h"

#include <cstdlib>
#include <algorithm>

template class Matrix<double>;
template class Matrix<float>;
template class Matrix<int>;