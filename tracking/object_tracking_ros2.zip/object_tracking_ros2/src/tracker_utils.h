constexpr int kNumColors = 32;

constexpr int kMaxCoastCycles = 1;

constexpr int KMinHints = 3;

constexpr float kMinConfidence = 0.6;